package edu.mum.cs.cs425.studentmgmt.model;

import lombok.Data;

import javax.persistence.*;
import java.util.List;
@Data

@Entity
public class Course {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="course_id")
    private int courseId;
    @Column(nullable=false, unique=true)
    private String name;
    @Column(name="course_code")
    private String courseCode;
    @Column(name="number_of_units")
    private float numberOfUnits;

    @ManyToMany(mappedBy="courses")
    private List<Student> students;


}
