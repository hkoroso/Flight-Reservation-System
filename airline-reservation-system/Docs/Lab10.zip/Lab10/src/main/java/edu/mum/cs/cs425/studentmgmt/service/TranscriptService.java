package edu.mum.cs.cs425.studentmgmt.service;

import edu.mum.cs.cs425.studentmgmt.model.Transcript;

public interface TranscriptService {
    public Transcript save(Transcript t);
}
