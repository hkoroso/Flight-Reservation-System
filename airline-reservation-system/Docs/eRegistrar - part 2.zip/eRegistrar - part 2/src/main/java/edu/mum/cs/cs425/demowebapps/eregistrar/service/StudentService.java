package edu.mum.cs.cs425.demowebapps.eregistrar.service;

import edu.mum.cs.cs425.demowebapps.eregistrar.model.Student;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface StudentService {
     List<Student> findAll();
     Student findById(Long id);
     Student addStudent(Student student);
     void removeStudent(Long id);
     Student updateStudent(Long id, Student student);

}
