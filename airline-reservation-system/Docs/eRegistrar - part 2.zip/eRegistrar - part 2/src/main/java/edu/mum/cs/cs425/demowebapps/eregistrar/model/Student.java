package edu.mum.cs.cs425.demowebapps.eregistrar.model;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.time.LocalDateTime;

@Data

@Entity
public class Student {
    @Id
    @GeneratedValue
    private Long studentId;

    @Column(nullable = false)
    private String studentNumber;
    @Column(nullable = false)
    private String firstName;
    private String middleName;
    @Column(nullable = false)
    private String lastName;
    private String cgpa;
    @Column(nullable = false)
    private LocalDateTime enrollmentData;
    @Column(nullable = false)
    private String isInternational;


}
