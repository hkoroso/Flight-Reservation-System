package edu.mum.cs.cs425.demowebapps.eregistrar.controller;

import edu.mum.cs.cs425.demowebapps.eregistrar.model.Student;
import edu.mum.cs.cs425.demowebapps.eregistrar.repository.StudentRepository;
import edu.mum.cs.cs425.demowebapps.eregistrar.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
public class StudentController {
    @Autowired
    StudentRepository studentRepository;
    @Autowired
    StudentService studentService;

    @GetMapping(value = "/students")
    public List<Student> findAll() {
        return studentService.findAll();
    }

    @PostMapping(value = "/add/student")
    public Student addStudent(@Valid @RequestBody Student student) {

        return studentService.addStudent(student);
    }

    @GetMapping(value = "/students/{id}")
    public Student findById(@PathVariable Long id) {
        return studentService.findById(id);
    }

    @PutMapping(value = "/students/{id}")
    public Student updateStudent(@Valid @RequestBody Student student, @PathVariable Long id) {
        return studentService.updateStudent(id,student);
    }

    @DeleteMapping(value = "/students/{id}")
    public void removeStudent(@PathVariable Long id) {
        studentService.removeStudent(id);
    }



}
