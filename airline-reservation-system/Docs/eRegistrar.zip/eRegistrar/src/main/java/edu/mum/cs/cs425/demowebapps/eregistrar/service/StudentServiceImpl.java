package edu.mum.cs.cs425.demowebapps.eregistrar.service;

import edu.mum.cs.cs425.demowebapps.eregistrar.model.Student;
import edu.mum.cs.cs425.demowebapps.eregistrar.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class StudentServiceImpl implements StudentService {
    @Autowired
    private StudentRepository studentRepository;


    @Override
    public List<Student> findAll() {
        return studentRepository.findAll();
    }

    @Override
    public Student findById(Long id) {
        return studentRepository.findById(id).orElse(null);
    }

    @Override
    public void removeStudent(Long id) {
        Student student = studentRepository.findById(id).orElse(null);

        studentRepository.delete(student);
    }


    @Override
    public Student addStudent(Student student) {
        Student student1 = new Student();
        student1.setStudentNumber(student.getStudentNumber());
        student1.setFirstName(student.getFirstName());
        student1.setMiddleName(student.getMiddleName());
        student1.setLastName(student.getLastName());
        student1.setCgpa(student.getCgpa());
        student1.setEnrollmentData(student.getEnrollmentData());
        student1.setIsInternational(student.getIsInternational());
        return studentRepository.save(student1);
    }
    @Override
    public Student updateStudent(Long id, Student student){
        Student student1 = studentRepository.findById(id).orElse(null);
        student1.setStudentNumber(student.getStudentNumber());
        student1.setFirstName(student.getFirstName());
        student1.setMiddleName(student.getMiddleName());
        student1.setLastName(student.getLastName());
        student1.setCgpa(student.getCgpa());
        student1.setEnrollmentData(student.getEnrollmentData());
        student1.setIsInternational(student.getIsInternational());
        studentRepository.flush();
        return studentRepository.save(student1);
    }

}
